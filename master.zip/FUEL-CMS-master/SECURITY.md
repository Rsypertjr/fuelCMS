# Security Policy

Security updates are first pushed to the develop branch and then merged into the master branch upon release to the latest version.

To report a vulnerability, please email info@getfuelcms.com instead of reporting it as an issue.
