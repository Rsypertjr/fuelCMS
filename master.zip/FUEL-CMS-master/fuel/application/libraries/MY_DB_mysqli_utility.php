<?php 
// to simplify updates, we post the main files in the fuel module
require_once(FUEL_PATH.'libraries/MY_DB_mysqli_utility.php');